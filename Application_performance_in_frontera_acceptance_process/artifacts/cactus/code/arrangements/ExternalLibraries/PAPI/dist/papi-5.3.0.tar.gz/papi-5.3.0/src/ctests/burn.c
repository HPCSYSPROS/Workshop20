#include "papi_test.h"
int
main(  )
{
	do_stuff(  );
	exit( 0 );
}
